import React from 'react';
import { createStackNavigator } from '@react-navigation/stack';

import One_Main from '../screens/One_Main';
import One_Login from '../screens/One_Login';
import One_Sign from '../screens/One_Sign';
import Two_Board from '../screens/Two_Board';
import Nickname from './Navigator';
import Two_Board_Add from '../screens/Two_Board_Add';
import Two_Board_Filter from '../screens/Two_Board_Filter';
import Three_Chat from '../screens/Three_Chat';
import Three_Chat_Private from '../screens/Three_Chat_Private';
import Board_Update from '../screens/Board_Update';
import Four_Message from '../screens/Four_Message';

const Stack = createStackNavigator();

const StackNavigation = () => {
    return (
        <Stack.Navigator initialRouteName='List'>
            <Stack.Screen
                options={{headerShown: false}}
                name='Main' component={One_Main} />
            <Stack.Screen name='Login' component={One_Login} />
            <Stack.Screen name='Sign' component={One_Sign} />
            <Stack.Screen name='Board' component={Two_Board} />
            <Stack.Screen
                options={{headerShown: false}}
                name='Nickname' component={Nickname} />
            <Stack.Screen name='Board_Add' component={Two_Board_Add} />
            <Stack.Screen name='Board_Filter' component={Two_Board_Filter} />
            <Stack.Screen name='Chat' component={Three_Chat} />
            <Stack.Screen
                options={{headerShown: false}} 
                name='Chat_Private' component={Three_Chat_Private} />
            <Stack.Screen name='Board_Update' component={Board_Update} />
            <Stack.Screen name='Message' component={Four_Message} />
        </Stack.Navigator>
    );
};

export default StackNavigation;