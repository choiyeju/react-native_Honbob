import React from 'react';
import { Text, AppRegistry, StyleSheet, TextInput, View, Alert, Button } from 'react-native';
import styled from 'styled-components/native';
import database from '@react-native-firebase/database';

const Container = styled.View`
    flex: 1;
    backgroundColor: ivory;
    justify-content: center;
    align-items: center;
`;

const StyledText = styled.Text`
    font-size: 30px;
    margin-bottom: 10px;
`;

var userCount = 0;
var nickname = '';
var age = 0;
var id = '';
var password = '';

var starCountRef = database().ref('userCount/Id');
starCountRef.on('value', (snapshot) => {
    const data = snapshot.val();
    userCount = data;
});

function Sign(userId, nickname, age, id, password) {
    database().ref('user/' + (userId+1)).set({
        nickname : nickname,
        age : age,
        id : id,
        password : password,
    });
    database().ref('userCount/').set({
        Id: userId+1
    });
}

const One_Sign = () => {
    return (
        <Container>
            <View style={styles.MainContainer}>
                    <TextInput
                        placeholder="Nickname"
                        onChangeText={(TextInputNickname) => nickname = TextInputNickname}
                        underlineColorAndroid='transparent'
                        style={styles.TextInputStyleClass}
                    />
                    <TextInput
                        placeholder="Age"
                        onChangeText={(TextInputAge) => age = TextInputAge}
                        underlineColorAndroid='transparent'
                        style={styles.TextInputStyleClass}
                    />
                    <TextInput
                        placeholder="Id"
                        onChangeText={(TextInputId) => id = TextInputId}
                        underlineColorAndroid='transparent'
                        style={styles.TextInputStyleClass}
                    />
                    <TextInput
                        placeholder="Password"
                        onChangeText={(TextInputPassword) => password = TextInputPassword}
                        underlineColorAndroid='transparent'
                        style={styles.TextInputStyleClass}
                    />
                    <Button title="Sign" onPress={() => Sign(userCount, nickname, age, id, password)} />
            </View>
        </Container>
    );
}

 
const styles = StyleSheet.create({
    MainContainer :{
        flex:1,
        margin: 10,
        justifyContent: 'center',
    },
    TextInputStyleClass: {
        textAlign: 'center',
        marginBottom: 7,
        height: 40,
        borderWidth: 2,
        borderColor: 'skyblue',
        width: 200,
    }
});

export default One_Sign;