import React, { Component } from 'react';
import { StyleSheet, View, TextInput, Text, Alert, ActivityIndicator, TouchableOpacity, Button } from 'react-native';
import styled from 'styled-components/native';
import database from '@react-native-firebase/database';

// database().ref('/board/1')
//   .set({
//     menu: 'a',
//     time: 1,
//     place: 'a',
//     age: 1,
//   })
// .then(() => console.log('Data set.'));

var boardCount = 0;
var starCountRef = database().ref('boardCount/Id');
starCountRef.on('value', (snapshot) => {
    const data = snapshot.val();
    boardCount = data;
});
var nickname = 'a';

function writeUserData(userId, nickname, menu, time, place, age) {
    database().ref('board/' + (userId+1)).set({
        boardId : userId+1,
        nickname : nickname,
        menu : menu,
        time : time,
        place : place,
        age : age
    });
    database().ref('boardCount/').update({
        Id: userId+1
    });
}

const Container = styled.View`
    flex: 1;
    backgroundColor: ivory;
    justify-content: flex-start;
    align-items: flex-start;
`;

const StyledText = styled.Text`
    font-size: 30px;
    margin-bottom: 10px;
`;

export default class Two_Board_Add extends Component
{
    state = {
        Product_Menu: '',
        Product_Time: '',
        Product_Place: '',
        Product_Age: '',
    }
    
    render(){
    const {navigation} = this.props;
    return (
        <Container>
            <View style={styles.MainContainer}>
                <View style={styles.SecondContainer}>
                    <View style={{flex:1,margin: 10, alignItems: 'flex-start',}}>
                        <Text style={{fontSize: 25,}}>Menu</Text>
                        <Text>{boardCount}</Text>
                    </View>
                    <TextInput
                        placeholder="menu"
                        onChangeText={(TextInputMenu) => this.setState({Product_Menu : TextInputMenu})}
                        underlineColorAndroid='transparent'
                        style={styles.TextInputStyleClass}
                    />
                    <View style={{flex:1,}}></View>
                </View>
                <View style={styles.SecondContainer}>
                    <View style={{flex:1,margin: 10, alignItems: 'flex-start',}}>
                        <Text style={{fontSize: 25,}}>Time</Text>
                    </View>
                    <TextInput
                        placeholder="time"
                        onChangeText={(TextInputTime) => this.setState({Product_Time : TextInputTime})}
                        underlineColorAndroid='transparent'
                        style={styles.TextInputStyleClass}
                    />
                    <View style={{flex:1,}}></View>
                </View>
                <View style={styles.SecondContainer}>
                    <View style={{flex:1,margin: 10, alignItems: 'flex-start', width: '10%',}}>
                        <Text style={{fontSize: 25,}}>Place</Text>
                    </View>
                    <TextInput
                        placeholder="place"
                        onChangeText={(TextInputPlace) => this.setState({Product_Place : TextInputPlace})}
                        underlineColorAndroid='transparent'
                        style={styles.TextInputStyleClass}
                    />
                    <View style={{flex:1,}}></View>
                </View>
                <View style={styles.SecondContainer}>
                    <View style={{flex:1,margin: 10, alignItems: 'flex-start',}}>
                        <Text style={{fontSize: 25,}}>Age</Text>
                    </View>
                    <TextInput
                        placeholder="age"
                        onChangeText={(TextInputAge) => this.setState({Product_Age : TextInputAge})}
                        underlineColorAndroid='transparent'
                        style={styles.TextInputStyleClass}
                    />
                    <View style={{flex:1,}}></View>
                </View>
            </View>
            <View style={{width: '100%', alignItems: 'flex-end',}}>
                <View style={styles.bottom}>
                    <Button title='Board_Add' onPress = {() => writeUserData(boardCount, nickname, this.state.Product_Menu, this.state.Product_Time, this.state.Product_Place, this.state.Product_Age)} />
                </View>
            </View>
            <View style={styles.bottom}>
                <View style={{flex:1,margin: 20, alignItems: 'flex-start',}}>
                    <Text style={{fontSize: 20,}}>Board</Text>
                </View>
            </View>
        </Container>
    )
    }
}


const styles = StyleSheet.create({
    MainContainer : {
        flex:1,
        margin: 10,
        justifyContent: 'flex-start',
        alignItems: 'flex-start',
    },
    SecondContainer: {
        flexDirection: 'row',
    },
    TextInputStyleClass: {
        textAlign: 'center',
        marginBottom: 10,
        borderWidth: 2,
        borderColor: 'skyblue',
        width: 200,
    },
    bottom : {
        margin: 5,
        width: '30%',
    },
});

// export default Two_Board_Add;