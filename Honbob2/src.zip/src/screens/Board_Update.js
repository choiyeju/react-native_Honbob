//menu time place age에 값을 안적으면 본래 값이 사라짐
//삭제 기능 안됨
import React, { Component } from 'react';
import { StyleSheet, View, TextInput, Text, Alert, ActivityIndicator, TouchableOpacity, Button } from 'react-native';
import styled from 'styled-components/native';
import database from '@react-native-firebase/database';

const Container = styled.View`
    flex: 1;
    backgroundColor: ivory;
    justify-content: flex-start;
    align-items: flex-start;
`;

function UpdateBoardData(userId, nickname, menu, time, place, age) {
    database().ref('board/' + userId).update({
        nickname: nickname,
        menu : menu,
        time : time,
        place : place,
        age : age
    });
}
function DeleteBoardData(userId) {
    database().ref('board/' + userId).remove();
}

export default class Two_Board_Update extends Component
{
    state = {
        Product_Menu: '',
        Product_Time: '',
        Product_Place: '',
        Product_Age: '',
    }
    
    render(){
    const {navigation} = this.props;
    var boardId= this.props.route.params.moving;
    var ref = {}

    var getBoard_One = database().ref('board/' + boardId);
    getBoard_One.on('value', (snapshot) => {
        ref = snapshot.val();
    });

    return (
        
        <Container>
            <View style={styles.MainContainer}>
                <View style={styles.SecondContainer}>
                    <View style={{flex:1,margin: 10, alignItems: 'flex-start',}}>
                        <Text style={{fontSize: 25,}}>Menu</Text>
                        <Text>{boardId}</Text>
                    </View>
                    <TextInput
                        placeholder={ref.menu}
                        onChangeText={(TextInputMenu) => this.setState({Product_Menu : TextInputMenu})}
                        underlineColorAndroid='transparent'
                        style={styles.TextInputStyleClass}
                    />
                    <View style={{flex:1,}}></View>
                </View>
                <View style={styles.SecondContainer}>
                    <View style={{flex:1,margin: 10, alignItems: 'flex-start',}}>
                        <Text style={{fontSize: 25,}}>Time</Text>
                    </View>
                    <TextInput
                        placeholder={ref.time}
                        onChangeText={(TextInputTime) => this.setState({Product_Time : TextInputTime})}
                        underlineColorAndroid='transparent'
                        style={styles.TextInputStyleClass}
                    />
                    <View style={{flex:1,}}></View>
                </View>
                <View style={styles.SecondContainer}>
                    <View style={{flex:1,margin: 10, alignItems: 'flex-start', width: '10%',}}>
                        <Text style={{fontSize: 25,}}>Place</Text>
                    </View>
                    <TextInput
                        placeholder={ref.place}
                        onChangeText={(TextInputPlace) => this.setState({Product_Place : TextInputPlace})}
                        underlineColorAndroid='transparent'
                        style={styles.TextInputStyleClass}
                    />
                    <View style={{flex:1,}}></View>
                </View>
                <View style={styles.SecondContainer}>
                    <View style={{flex:1,margin: 10, alignItems: 'flex-start',}}>
                        <Text style={{fontSize: 25,}}>Age</Text>
                    </View>
                    <TextInput
                        placeholder={ref.age}
                        onChangeText={(TextInputAge) => this.setState({Product_Age : TextInputAge})}
                        underlineColorAndroid='transparent'
                        style={styles.TextInputStyleClass}
                    />
                    <View style={{flex:1,}}></View>
                </View>
            </View>
            <View style={{ flexDirection: 'row', width: '100%', alignItems: 'flex-end',}}>
                <View style={styles.bottom}></View>
                <View style={styles.bottom}>
                    <Button title='Board_Update' onPress = {() => UpdateBoardData(boardId, ref.nickname, this.state.Product_Menu, this.state.Product_Time, this.state.Product_Place, this.state.Product_Age)} />
                </View>
                <View style={styles.bottom}>
                    <Button title='Board_Delete' onPress = {() => DeleteBoardData(boardId)} />
                </View>
                
            </View>
            <View style={styles.bottom}>
                <View style={{flex:1,margin: 20, alignItems: 'flex-start',}}>
                    <Text style={{fontSize: 20,}}>Board</Text>
                </View>
            </View>
        </Container>
    )
    }
}


const styles = StyleSheet.create({
    MainContainer : {
        flex:1,
        margin: 10,
        justifyContent: 'flex-start',
        alignItems: 'flex-start',
    },
    SecondContainer: {
        flexDirection: 'row',
    },
    TextInputStyleClass: {
        textAlign: 'center',
        marginBottom: 10,
        borderWidth: 2,
        borderColor: 'skyblue',
        width: 200,
    },
    bottom : {
        margin: 5,
        width: '30%',
    },
});

// export default Two_Board_Update;