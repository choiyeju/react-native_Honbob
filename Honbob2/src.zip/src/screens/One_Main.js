import React from 'react';
import { Button } from 'react-native';
import styled from 'styled-components/native';

import {
    SafeAreaView,
    ScrollView,
    StatusBar,
    StyleSheet,
    Text,
    useColorScheme,
    View,
} from 'react-native';

const Container = styled.View`
    flex: 1;
    backgroundColor: ivory;
    justify-content: center;
    align-items: center;
`;

const StyledText = styled.Text`
    font-size: 30px;
    margin-bottom: 10px;
`;

const One_Main = ({navigation}) => {
    return (
        <Container>
            <View style={styles.center}>
                <Button title='Login' onPress = {() => navigation.navigate('Login')} />
            </View>
            <View style={styles.center}>
                <Button title='Sign' onPress = {() => navigation.navigate('Sign')} />
            </View>
            {/* <View style={styles.center}>
                <Button title='Board' onPress = {() => navigation.navigate('Board')} />
            </View> */}
            <View style={styles.center}>
                <Button title='Nickname' onPress = {() => navigation.navigate('Nickname')} />
            </View>
        </Container>
    )
}

const styles = StyleSheet.create({
    center : {
        margin: 5,
        width: '35%',
    },
});

export default One_Main;