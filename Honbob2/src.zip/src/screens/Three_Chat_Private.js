import React, { Component } from 'react';
import { Button } from 'react-native';
import styled from 'styled-components/native';

import {
    SafeAreaView,
    ScrollView,
    StatusBar,
    StyleSheet,
    Text,
    useColorScheme,
    View,
} from 'react-native';
import { render } from 'express/lib/response';

const Container = styled.View`
    flex: 1;
    backgroundColor: ivory;
    justify-content: center;
    align-items: center;
`;

const StyledText = styled.Text`
    font-size: 30px;
    margin-bottom: 10px;
`;

// function Chat_Private ({navigation}) {
//     return (
        
//     );
// };

export default class Three_Chat_Private extends Component
{
    render(){
    const {navigation} = this.props;
    var boardId = this.props.route.params.moving;
    return (
        <Container>
            <View style={styles.top_bar}>
                <View style={{flex:1,margin: 10, alignItems: 'flex-start',}}>
                    <Text style={{fontSize: 20,}}>ChatPrivate</Text>
                </View>
                <View style={styles.top_1}>
                    <Button title='Main' onPress = {() => navigation.navigate('Main')} />
                </View>
                <View style={styles.top_2}>
                    <Button title='Board_Update' onPress = {() => navigation.navigate('Board_Update', {moving: boardId})}>update</Button>
                </View>
            </View>
            <View style={styles.center}>
                <View style={styles.center_1}>
                    <Text>{this.props.route.params.moving}</Text>
                </View>
            </View>
        </Container>
    )
    }
}

const styles = StyleSheet.create({
    top_bar: {
        width: '100%',
        height: '10%',
        flexDirection: 'row',
        backgroundColor: 'white',
        alignItems: 'center',
        justifyContent: 'flex-end',
    },
    top_1 : {
        flex:1,
        margin: 5,
        width: '30%',
        // alignItems: 'flex-start',
        // justifyContent: 'flex-start',
    },
    top_2 : {
        flex: 1,
        margin: 5,
        width: '30%',
        // alignItems: 'flex-end',
        // justifyContent: 'flex-end',
    },
    center : {
        flex:1,
        margin: 5,
        width: '100%',
        alignItems: 'center',
        justifyContent: 'center',
    },
    center_1 : {
        flex: 1,
        padding: 5,
        margin: 5,
        width: '100%',
        backgroundColor: 'skyblue',
    },
});

// export default Three_Chat_Private;