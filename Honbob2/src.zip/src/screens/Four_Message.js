import React from 'react';
import { Button } from 'react-native';
import styled from 'styled-components/native';

import {
    SafeAreaView,
    ScrollView,
    StatusBar,
    StyleSheet,
    Text,
    useColorScheme,
    View,
} from 'react-native';

const Container = styled.View`
    flex: 1;
    backgroundColor: ivory;
    justify-content: center;
    align-items: center;
`;

const StyledText = styled.Text`
    font-size: 30px;
    margin-bottom: 10px;
`;

const Four_Message = () => {
    return (
        <Container>
            <View style={styles.top_bar}>
                <View style={{flex:1,margin: 10, alignItems: 'flex-start',}}>
                    <Text style={{fontSize: 20,}}>Message</Text>
                </View>
                <View style={styles.top_1}>
                </View>
                <View style={styles.top_2}>
                </View>
            </View>
            <View style={styles.center}>
            </View>
        </Container>
    )
}

const styles = StyleSheet.create({
    top_bar: {
        width: '100%',
        height: '10%',
        flexDirection: 'row',
        backgroundColor: 'white',
        alignItems: 'center',
        justifyContent: 'flex-end',
    },
    top_1 : {
        flex:1,
        margin: 5,
        width: '30%',
        // alignItems: 'flex-start',
        // justifyContent: 'flex-start',
    },
    top_2 : {
        flex: 1,
        margin: 5,
        width: '30%',
        // alignItems: 'flex-end',
        // justifyContent: 'flex-end',
    },
    center : {
        flex:1,
        margin: 5,
        width: '20%',
        justifyContent: 'center',
    },
});

export default Four_Message;