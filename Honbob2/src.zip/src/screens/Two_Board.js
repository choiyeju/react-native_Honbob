//데이터가 가져와지지 않음
//SectionList 크기가 이상함
import RenderHTML from 'react-native-render-html';
import React, { Component } from 'react';
import { SectionList, FlatList, Button, useWindowDimensions  } from 'react-native';
import styled from 'styled-components/native';
import database from '@react-native-firebase/database';
import PropTypes from "prop-types";

import {
    SafeAreaView,
    ScrollView,
    StatusBar,
    StyleSheet,
    Text,
    useColorScheme,
    View,
} from 'react-native';

const Container = styled.View`
    flex: 1;
    backgroundColor: ivory;
    justify-content: center;
    align-items: center;
`;

var boardCount = 0;
var getBoardCount = database().ref('boardCount/Id');
getBoardCount.on('value', (snapshot) => {
    const data = snapshot.val();
    boardCount = data;
});
var ref = [];
var getBoard = database().ref('board/');
getBoard.on('value', (snapshot) => {
    ref = snapshot.val();
    ref = ref.filter(function(item) {
        return item !== null;
    });
});


// import firebase from 'firebase';
export default class Two_Board extends Component 
{
    render(){
    const {navigation} = this.props;
    // var ref_list2 = GetData_All();
    // console.log(ref_list2[1]);
    return (
        <Container>
            <View style={styles.top_bar}>
                <View style={{flex:1,margin: 10, alignItems: 'flex-start',}}>
                    <Text style={{fontSize: 20,}}>Board</Text>
                </View>
                <View style={styles.top_1}>
                    <Button title='Main' onPress = {() => navigation.navigate('Main')} />
                </View>
                <View style={styles.top_2}>
                    <Button title='Board_Filter' onPress = {() => navigation.navigate('Board_Filter')} />
                </View>
            </View>
            <View style={styles.center}>
                <FlatList
                    data={ref.reverse()}
                    renderItem={({item}) => 
                    <View style={styles.center_1}>
                        <Button title={item.nickname} onPress = {() => navigation.navigate('Chat_Private', {moving: item.boardId})}></Button>
                        <View>
                            <Text>                                                                            </Text>
                            <View style={{flexDirection: 'row',}}>
                                <Text style={{fontSize: 15, }}>메뉴: </Text>
                                <View style = {styles.center_2}>
                                    <Text>{item.menu}</Text>
                                </View>
                            </View>
                            <View style={{flexDirection: 'row',}}>
                                <Text style={{fontSize: 15, }}>시간: </Text>
                                <View style = {styles.center_2}>
                                    <Text>{item.time}</Text>
                                </View>
                            </View>
                            <View style={{flexDirection: 'row',}}>
                                <Text style={{fontSize: 15, }}>장소: </Text>
                                <View style = {styles.center_2}>
                                    <Text>{item.place}</Text>
                                </View>
                            </View>
                            <View style={{flexDirection: 'row',}}>
                                <Text style={{fontSize: 15, }}>나이: </Text>
                                <View style = {styles.center_2}>
                                    <Text>{item.age}</Text>
                                </View>
                            </View>
                        </View>
                </View>
                }
                />
                {/* <Text>{Board_List_Element}</Text>
                <RenderHTML contentWidth={width} source={{html}} /> */}
            </View>
            <View style={{width: '100%', alignItems: 'flex-end',}}>
                <View style={styles.bottom}>
                    <Button title='Board_Add' onPress = {() => navigation.navigate('Board_Add')} />
                </View>
            </View>
        </Container>
        
    );
    }
        
}

const styles = StyleSheet.create({
    top_bar: {
        width: '100%',
        height: '10%',
        flexDirection: 'row',
        backgroundColor: 'white',
        alignItems: 'center',
        justifyContent: 'flex-end',
    },
    top_1 : {
        flex:1,
        margin: 5,
        width: '30%',
        // alignItems: 'flex-start',
        // justifyContent: 'flex-start',
    },
    top_2 : {
        flex: 1,
        margin: 5,
        width: '30%',
        // alignItems: 'flex-end',
        // justifyContent: 'flex-end',
    },
    center : {
        margin: 5,
        width: '100%',
        height: '80%',
        alignItems: 'center',
        justifyContent: 'center',
    },
    center_1 : {
        flex: 1,
        padding: 5,
        margin: 5,
        width: '97%',
        backgroundColor: 'skyblue',

    },
    center_2 : {
        flex: 1,
        padding: 5,
        margin: 5,
        flexDirection: 'row',
        width: '96%',
        backgroundColor: 'white',
    },
    bottom : {
        margin: 5,
        width: '30%',
    },
});

// export default Two_Board;