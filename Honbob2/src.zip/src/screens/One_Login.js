import React, { useEffect, useState } from 'react';
import { Text, AppRegistry, StyleSheet, TextInput, View, Alert, Button } from 'react-native';
import styled from 'styled-components/native';
// import { MaterialCommunityIcons } from '@expo/vector-icons';
// import firebase from 'react-native-firebase';

const Container = styled.View`
    flex: 1;
    backgroundColor: ivory;
    justify-content: center;
    align-items: center;
`;

const StyledText = styled.Text`
    font-size: 30px;
    margin-bottom: 10px;
`;



const One_Login = ({navigation, route}) => {
    return (
        <Container>
            <View style={styles.MainContainer}>
                    <TextInput
                        placeholder="Id"
                        onChangeText={TextInputName => this.setState({TextInputName})}
                        underlineColorAndroid='transparent'
                        style={styles.TextInputStyleClass}
                    />
                    <TextInput
                        placeholder="Passworld"
                        onChangeText={TextInputEmail => this.setState({TextInputEmail})}
                        underlineColorAndroid='transparent'
                        style={styles.TextInputStyleClass}
                    />
                    <Button title="Login" onPress={this.InsertDataToServer} />
            </View>
        </Container>
    );
}

 
const styles = StyleSheet.create({
    MainContainer :{
        flex:1,
        margin: 10,
        justifyContent: 'center',
    },
    TextInputStyleClass: {
        textAlign: 'center',
        marginBottom: 7,
        height: 40,
        borderWidth: 2,
        borderColor: 'skyblue',
        width: 200,
    }
});

export default One_Login;